#ifndef AES_H
#define AES_H

#include <stddef.h> // Include for size_t
#include "../types/encryption_algorithm.h"
#include "../types/constants.h"
// extern declarations
extern char aes_key[AES_KEY_SIZE];
extern char roundKeys[11][16];
extern char key[AES_KEY_SIZE]; 
// Function declarations
void aes_generate_key(char *key, size_t key_size);
void aes_initialize(const char *key);
void aes_encrypt(const char *filePath);
void aes_decrypt(const char *filePath);

void aes_key_expansion(const char *key, char roundKeys[11][16]);
void aes_mix_columns(char *state);
void aes_mix_rows(char *state);
void aes_add_round_constant(char *state, int round);

extern EncryptionAlgorithm aes_algorithm;

#endif // AES_H