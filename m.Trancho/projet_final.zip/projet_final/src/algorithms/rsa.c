#include "rsa.h"
#include <gmp.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "../types/constants.h"

void initializeRSA() {
    mpz_inits(p, q, n, phi, e, d, NULL);
    srand(time(NULL)); // Seed the random number generator
}

void clearRSA() {
    mpz_clears(p, q, n, phi, e, d, NULL);
}

int isPrime(mpz_t num) {
    return mpz_probab_prime_p(num, 25);
}

void generatePrime(mpz_t prime) {
    gmp_randstate_t state;
    gmp_randinit_default(state);
    gmp_randseed_ui(state, rand());
    do {
        mpz_urandomb(prime, state, MIN_PRIME_BITS);
    } while (!isPrime(prime));
    gmp_randclear(state);  
}

void gcd(mpz_t result, mpz_t a, mpz_t b) {
    mpz_gcd(result, a, b);
}

void modInverse(mpz_t result, mpz_t e, mpz_t phi) {
    mpz_invert(result, e, phi);
}

void generateKeys() {
    generatePrime(p);
    generatePrime(q);
    mpz_mul(n, p, q);
    mpz_sub_ui(p, p, 1);
    mpz_sub_ui(q, q, 1);
    mpz_mul(phi, p, q);

    // Find e
    mpz_set_ui(e, 65537); // Common choice for e

    // Find d
    modInverse(d, e, phi);

    // Print keys and modulus as a mix of characters and numbers
    char publicKey[MIN_PRIME_BITS / 8];
    char privateKey[MIN_PRIME_BITS / 8];
    char modulus[MIN_PRIME_BITS / 8];
    mpz_get_str(publicKey, 62, e); // Base 62 for mix of characters and numbers
    mpz_get_str(privateKey, 62, d);
    mpz_get_str(modulus, 62, n);

    printf("Generated public key: %s\n", publicKey);
    printf("Generated private key: %s\n", privateKey);
    printf("Modulus: %s\n", modulus);
}

void encryptFile(const char *filePath) {
    FILE *in = fopen(filePath, "rb");
    FILE *out = fopen("temp_encrypted_file", "wb");

    if (!in || !out) {
        perror("Error opening file");
        if (in) fclose(in);
        if (out) fclose(out);
        exit(EXIT_FAILURE);
    }

    unsigned char buffer;
    mpz_t plain, cipher;
    mpz_inits(plain, cipher, NULL);

    while (fread(&buffer, sizeof(unsigned char), 1, in)) {
        mpz_set_ui(plain, buffer);
        mpz_powm(cipher, plain, e, n);

        size_t count;
        unsigned char *cipher_data = (unsigned char *)mpz_export(NULL, &count, 1, 1, 0, 0, cipher);
        fwrite(&count, sizeof(size_t), 1, out);
        fwrite(cipher_data, 1, count, out);
        free(cipher_data);
    }

    mpz_clears(plain, cipher, NULL);
    fclose(in);
    fclose(out);

    if (remove(filePath) != 0 || rename("temp_encrypted_file", filePath) != 0) {
        perror("Error renaming file");
        exit(EXIT_FAILURE);
    }
}

void decryptFile(const char *filePath) {
    mpz_t key;
    mpz_t modulus;
    FILE *in = fopen(filePath, "rb");
    FILE *out = fopen("temp_decrypted_file", "wb");
    printf("Enter the decryption key (d): ");
    gmp_scanf("%Zd", key);
    printf("Enter the modulus (n): ");
    gmp_scanf("%Zd", modulus);
    if (!in || !out) {
        perror("Error opening file");
        if (in) fclose(in);
        if (out) fclose(out);
        exit(EXIT_FAILURE);
    }

    mpz_t cipher, plain;
    mpz_inits(cipher, plain, NULL);

    while (1) {
        size_t count;
        if (fread(&count, sizeof(size_t), 1, in) != 1) break;

        unsigned char *cipher_data = (unsigned char *)malloc(count);
        if (fread(cipher_data, 1, count, in) != count) {
            free(cipher_data);
            break;
        }

        mpz_import(cipher, count, 1, 1, 0, 0, cipher_data);
        free(cipher_data);

        mpz_powm(plain, cipher, key, modulus);
        unsigned char decryptedChar = (unsigned char)mpz_get_ui(plain);

        if (fwrite(&decryptedChar, sizeof(unsigned char), 1, out) != 1) {
            perror("Error writing to file");
            mpz_clears(cipher, plain, NULL);
            fclose(in);
            fclose(out);
            exit(EXIT_FAILURE);
        }
    }

    mpz_clears(cipher, plain, NULL);
    fclose(in);
    fclose(out);

    if (remove(filePath) != 0 || rename("temp_decrypted_file", filePath) != 0) {
        perror("Error renaming file");
        exit(EXIT_FAILURE);
    }
}

EncryptionAlgorithm rsa_algorithm = {
    .name = "RSA",
    .encrypt = encryptFile,
    .decrypt = decryptFile
};
